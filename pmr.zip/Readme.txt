PMR.EXE
Type: Trojan.GDI.Win32
OS Support: Windows 7 - Windows 11
Skidded? No!
By windows7

YouTube channel: @WINDOWS7777_t






























































yay
yay!